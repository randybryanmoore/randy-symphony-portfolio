// =========================================================================
// Richmond Symphony Advancement Systems & Operations Portfolio Suite
// Candidate: Randy Bryan Moore, MSW
// Complete Integrated Interactive Engine, Dual-Stream Annotation & Telemetry
// =========================================================================

(function() {
  const editorialAndPattern = /\band\b/gi;
  const editorialCopyAttributes = ['aria-label', 'placeholder', 'title'];

  function applyEditorialSeparators(root = document.body) {
    if (!root) return;

    const replaceText = (textNode) => {
      const parent = textNode.parentElement;
      if (!parent || parent.closest('script, style, code, pre, textarea')) return;
      if (editorialAndPattern.test(textNode.nodeValue)) {
        textNode.nodeValue = textNode.nodeValue.replace(editorialAndPattern, '&');
      }
      editorialAndPattern.lastIndex = 0;
    };

    if (root.nodeType === Node.TEXT_NODE) {
      replaceText(root);
      return;
    }

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let textNode;
    while ((textNode = walker.nextNode())) replaceText(textNode);

    if (root.nodeType === Node.ELEMENT_NODE) {
      const elements = [root, ...root.querySelectorAll('*')];
      elements.forEach((element) => {
        editorialCopyAttributes.forEach((attribute) => {
          const value = element.getAttribute(attribute);
          if (value && editorialAndPattern.test(value)) {
            element.setAttribute(attribute, value.replace(editorialAndPattern, '&'));
          }
          editorialAndPattern.lastIndex = 0;
        });
      });
    }
  }

  function initSuite() {
    applyEditorialSeparators();
    const editorialObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'characterData') applyEditorialSeparators(mutation.target);
        if (mutation.type === 'attributes') applyEditorialSeparators(mutation.target);
        mutation.addedNodes.forEach((node) => applyEditorialSeparators(node));
      });
    });
    editorialObserver.observe(document.body, {
      attributes: true,
      attributeFilter: editorialCopyAttributes,
      childList: true,
      characterData: true,
      subtree: true
    });

    let pinActive = false;
    let editActive = false;
    let currentMode = 'ai'; // 'ai' (review queue) or 'private' (personal journal)

    // =========================================================================
    // 1. Passcode Gate (Universal PIN: 0000 / Native iPad & Desktop Master Input)
    // =========================================================================
    const gateOverlay = document.getElementById('passcode-gate');
    const masterInput = document.getElementById('pin-master-input');
    const visualBoxes = document.querySelectorAll('.pin-digit-box');
    const pinGroup = document.getElementById('pin-input-group');
    const gateUnlockBtn = document.getElementById('gate-unlock-btn');
    const gateError = document.getElementById('gate-error');

    function clearGateError() {
      if (gateError) gateError.textContent = '';
      if (masterInput) masterInput.removeAttribute('aria-invalid');
    }

    function showGateError() {
      if (gateError) gateError.textContent = 'That access code is not recognized. Enter 0000.';
      if (masterInput) masterInput.setAttribute('aria-invalid', 'true');
    }

    function validateAccessCode() {
      if (!masterInput) return false;
      if (masterInput.value === '0000') {
        clearGateError();
        unlockDossier();
        return true;
      }
      showGateError();
      masterInput.focus();
      masterInput.select();
      return false;
    }

    function unlockDossier() {
      if (gateOverlay) {
        gateOverlay.classList.add('unlocked');
        gateOverlay.style.opacity = '0';
        gateOverlay.style.visibility = 'hidden';
        gateOverlay.style.pointerEvents = 'none';
        setTimeout(() => {
          gateOverlay.style.display = 'none';
        }, 350);
      }
      document.body.classList.remove('dossier-locked');
      document.documentElement.classList.remove('dossier-locked');
      clearGateError();
      try {
        sessionStorage.setItem('symphony_dossier_auth', 'true');
        sessionStorage.setItem('rbm_sym_unlocked', '1');
        localStorage.setItem('symphony_dossier_auth', 'true');
      } catch (e) {}
    }

    function lockDossier() {
      document.body.classList.add('dossier-locked');
      document.documentElement.classList.add('dossier-locked');
      try {
        sessionStorage.removeItem('symphony_dossier_auth');
        sessionStorage.removeItem('rbm_sym_unlocked');
        localStorage.removeItem('symphony_dossier_auth');
      } catch (e) {}
      if (gateOverlay) {
        gateOverlay.style.display = 'flex';
        gateOverlay.style.opacity = '1';
        gateOverlay.style.visibility = 'visible';
        gateOverlay.style.pointerEvents = 'auto';
        gateOverlay.classList.remove('unlocked');
        if (masterInput) {
          masterInput.value = '';
          updateVisualPins();
          setTimeout(() => masterInput.focus(), 100);
        }
      }
    }
    window.lockSymphonyDossier = lockDossier;

    function updateVisualPins() {
      if (!masterInput) return;
      const rawVal = masterInput.value.replace(/\D/g, '').slice(0, 4);
      masterInput.value = rawVal;

      visualBoxes.forEach((box, i) => {
        if (i < rawVal.length) {
          box.classList.add('filled');
          box.classList.remove('active');
        } else if (i === rawVal.length) {
          box.classList.remove('filled');
          box.classList.add('active');
        } else {
          box.classList.remove('filled');
          box.classList.remove('active');
        }
      });

      clearGateError();
      if (rawVal.length === 4) {
        setTimeout(validateAccessCode, 60);
      }
    }

    try {
      if (sessionStorage.getItem('symphony_dossier_auth') === 'true' || 
          sessionStorage.getItem('rbm_sym_unlocked') === '1' ||
          localStorage.getItem('symphony_dossier_auth') === 'true') {
        unlockDossier();
      } else if (gateOverlay) {
        document.body.classList.add('dossier-locked');
        document.documentElement.classList.add('dossier-locked');
        if (masterInput) {
          setTimeout(() => {
            masterInput.focus();
            updateVisualPins();
          }, 150);
        }
      }
    } catch (e) {}

    if (masterInput) {
      masterInput.addEventListener('input', updateVisualPins);
      masterInput.addEventListener('keyup', updateVisualPins);
      masterInput.addEventListener('paste', () => {
        setTimeout(updateVisualPins, 10);
      });
      masterInput.addEventListener('focus', updateVisualPins);
    }

    if (pinGroup && masterInput) {
      pinGroup.addEventListener('click', () => {
        masterInput.focus();
      });
    }

    if (gateUnlockBtn) {
      gateUnlockBtn.addEventListener('click', (e) => {
        e.preventDefault();
        validateAccessCode();
      });
    }

    // =========================================================================
    // 2. Scroll Progress Bar
    // =========================================================================
    const progressBar = document.getElementById('scroll-progress');
    if (progressBar) {
      window.addEventListener('scroll', () => {
        const total = document.documentElement.scrollHeight - window.innerHeight;
        if (total > 0) {
          progressBar.style.width = (window.scrollY / total * 100) + '%';
        }
      }, { passive: true });
    }

    // =========================================================================
    // 3. Build Telemetry & Comprehensive Cross-Agent Provenance Inspector
    // =========================================================================
    const buildBadge = document.getElementById('build-badge');
    const provModal = document.getElementById('build-provenance-modal');
    const provClose = document.getElementById('provenance-close-btn');
    const copyHandoffBtn = document.getElementById('provenance-copy-handoff-btn');
    const copyTelemetryBtn = document.getElementById('provenance-copy-telemetry-btn');
    const relockBtn = document.getElementById('provenance-relock-btn');
    let provenanceReturnFocus = null;

    const currentTelemetry = Object.freeze({
      schemaVersion: 1,
      serviceName: 'richmond-symphony-candidate-dossier',
      serviceVersion: '1.6.6',
      agent: 'CDX',
      agentProduct: 'Codex',
      repository: 'randybryanmoore/randybryanmoore-dot-us',
      branch: 'main',
      baseCommit: 'f8b60a4',
      publicUrl: 'https://symphony.randybryanmoore.us',
      releaseManifest: './release-manifest.json'
    });

    function getTelemetryTimestamps() {
      const now = new Date();
      return {
        iso: now.toISOString(),
        local: new Intl.DateTimeFormat('en-US', {
          timeZone: 'America/New_York',
          dateStyle: 'medium',
          timeStyle: 'long'
        }).format(now)
      };
    }

    function buildMachineTelemetry() {
      const generated = getTelemetryTimestamps();
      return `schema_version: ${currentTelemetry.schemaVersion}
generated_at: "${generated.iso}"
generated_at_local: "${generated.local}"
timezone: "America/New_York"
generator:
  agent: "${currentTelemetry.agent}"
  product: "${currentTelemetry.agentProduct}"
service:
  name: "${currentTelemetry.serviceName}"
  version: "${currentTelemetry.serviceVersion}"
source:
  repository: "${currentTelemetry.repository}"
  branch: "${currentTelemetry.branch}"
  base_commit: "${currentTelemetry.baseCommit}"
  working_tree: "release telemetry update"
lifecycle:
  local: true
  committed: true
  pushed: true
  pull_request_or_merged: false
  deployed: true
  staging: false
  production_verified: true
production:
  url: "${currentTelemetry.publicUrl}"
  state: "v1.6.6 live and verified"
  verified_at: "2026-08-20T17:52:00-04:00"
  first_verified_serving_candidate: "df5f99e"
release_artifacts:
  manifest: "${currentTelemetry.releaseManifest}"
  manifest_policy: "regenerate hashes after final source change and before deployment"
validation:
  prior_release_candidate_gate: "pass"
  structured_telemetry_export: "source_checks_pass"
  browser_interaction: "file URL automation unavailable; production HTTP readback used"
  production_readback: "pass"
security:
  access_gate: "client-side presentation convenience; not authentication"
  sensitive_values_in_export: false
blockers:
  - id: "DEPLOY-APPROVAL-001"
    severity: "high"
    status: "closed"
    description: "Randy explicitly authorized commit, push, deployment, and live publication."
notes:
  - "Self-reported engineering time is historical context, not measured observability data."
  - "A commit is not a push; a push is not a deployment; deployment is not live verification."`;
    }

    function buildCurrentHandoff() {
      const generated = getTelemetryTimestamps();
      return `# Current Agent Handoff — Richmond Symphony Candidate Dossier
Generated: ${generated.iso} (${generated.local}; America/New_York)
Schema: handoff-v1

This is the current operational snapshot. Reverify every changeable fact before acting. Historical detail belongs in the on-page version archive, not in this current-state handoff.

## 1. Current state
- Version: \`v${currentTelemetry.serviceVersion}\`
- Agent: Codex (\`CDX\`)
- Repository: \`${currentTelemetry.repository}\`, branch \`${currentTelemetry.branch}\`
- Source release lineage begins with: \`${currentTelemetry.baseCommit}\`
- Working area: \`symphony/\`
- Public URL: ${currentTelemetry.publicUrl}
- Release manifest: \`${currentTelemetry.releaseManifest}\` — hashes must be regenerated after the final source edit and before deployment

### Lifecycle — report each state separately
- Local: Yes — \`v${currentTelemetry.serviceVersion}\` release source validated.
- Committed: Yes — development repository \`main\`; use Git readback for the current commit.
- Pushed: Yes — development repository \`main\`.
- Merged / Pull Request: Direct-to-main release; no PR.
- Deployed: Yes — serving \`gh-pages\` and \`main\`; use Git readback for the current commit.
- Staging: Not used.
- Live / Production: \`v${currentTelemetry.serviceVersion}\` verified at the custom domain on Aug 20, 2026 at 5:52 PM EDT.

A commit is not a push. A push is not a deployment. A deployment is not confirmed live until production readback succeeds.

## 2. Privacy and access classification
- Distribution: Internal engineering handoff. Remove personal contact details and machine-specific paths before broader sharing.
- The four-digit overlay is a client-side presentation convenience, not authentication or confidentiality protection.
- Do not put passcodes, tokens, private-note contents, or credential-file paths in generated handoffs.
- Do not publish the dossier ZIP without explicit approval of its complete manifest.

## 3. Project invariants
- Purpose: source-grounded candidate dossier for Assistant Director, Advancement Systems & Operations at Richmond Symphony.
- Brand blue levels: \`#0d1a32\`, \`#182b4d\`, \`#243d6b\`.
- Canonical red: \`#2b0710\`; do not introduce a lighter red without explicit instruction.
- Preserve Playfair Display, Inter, and JetBrains Mono typography roles.
- Preserve private notes. Transient review notes may reset only through their documented export flow.

## 4. Claim policy
- Bloomerang: learning priority and role requirement, not prior administration experience.
- EveryAction: constituent engagement tagging, outreach lists, follow-up workflows, and event reporting; do not invent duration.
- Muster: requirements definition and Salesforce integration design for Active Minds across Congressional targets.
- Leadership: supervised graduate MSW interns and trained 40 partner organizations; do not imply prior supervision of Richmond Symphony staff.
- Musical Artistry is currently Section 03. Preserve the supplied sourced credentials and do not add unsupported fundraising software or experience.

## 5. Current release changes
- Corrected unsupported or overstated claims.
- Repaired incorrect-PIN acceptance and improved gate behavior while retaining the client-side-security disclaimer.
- Added explicit lifecycle states and telemetry accessibility/containment fixes.
- Updated case-study active states, layout accents, contact surfaces, Musical Artistry order, embedded-media annotation, and telemetry collapse behavior.
- Set the three TikTok cards to a centered 320px intermediate width without affecting unrelated responsive grids.
- Replaced the oversized default handoff with this current-state document and added a separate YAML telemetry export.
- Renamed the “Piano Repertoire” navigation link to “Music & Artistry.”
- Separated telemetry status colors: local candidates are gold, live production is green, and released history is blue.
- Adopted the main-site Playfair Display and Inter font system, retained JetBrains Mono for telemetry, and added the (( section label )) / // divider signature.
- Added a visible telemetry key explaining gold Local, green Live, blue Released, red Attention, and cream Information states with accompanying text labels.
- Made the telemetry color key keyboard-accessible, collapsible, and closed by default.
- Added a collapsed version-number key defining MAJOR.MINOR.PATCH thresholds, reset rules, example readings, and the pre-release meaning of -rc.
- Applied the dossier's editorial convention globally: visible standalone “and” becomes “&”, while existing “//” remains the structural divider.
- Added an engineering-time disclosure that previews on hover or focus, persists on click or tap, and documents the exact agent-hour arithmetic, active-block method, 10-minute break rule, exclusions, and historical precision limits.
- Relabeled every dashboard entry point as a fictional Advancement Intelligence concept prototype and added an adjacent no-live-systems / no-donor-data disclosure.

## 6. Safe release protocol
1. Explain the intended source changes in 3–7 bullets.
2. Inspect \`git status --short\` and the complete diff. Preserve unrelated local work.
3. Run the verified local build and the relevant interaction, responsive, accessibility, archive-integrity, and incorrect-PIN tests.
4. Regenerate \`release-manifest.json\` after the final edit. Confirm every artifact path and SHA-256 digest.
5. Inspect the dossier ZIP manifest for personal or sensitive payloads. Obtain explicit publication approval.
6. Stage only the named release files; never use \`git add -A\` as the default release instruction.
7. Commit with a release-specific message, then report Committed separately.
8. Push without force after verifying the upstream branch state, then report Pushed separately.
9. Use a protected deployment environment or an explicit approval checkpoint before changing serving branches.
10. After deployment, read back the GitHub Pages build, custom domain, version marker, and representative artifact hashes. Only then report Live / Production.

## 7. Deployment safety rules
- The Git Tree API may reduce partial-file update risk; it does not eliminate concurrent updates, caching, Pages build delays, or stale production responses.
- Do not force-update \`main\` or \`gh-pages\` unless the exact target commits are resolved and Randy explicitly authorizes that destructive branch operation.
- Do not combine build, stage, commit, push, deployment, and live verification into one unconditional shell chain.
- A failed or timed-out build, upload, or readback is not success.

## 8. Release evidence
- \`DEPLOY-APPROVAL-001\` — Closed. Randy explicitly authorized publication.
- Release lineage begins with source candidate \`f8b60a4\` on development \`main\`.
- First verified serving candidate: \`df5f99e\`; later lifecycle-only commits must be resolved through Git instead of embedded self-referential SHAs.
- Production readback: passed at the custom domain on Aug 20, 2026 at 5:52 PM EDT.

## 9. Machine-readable companion
Use “Copy Machine Telemetry (.YAML)” in the telemetry modal. Treat browser-generated state as a handoff snapshot, not as an independently verified Git or hosting measurement.`;
    }

    async function copyProvenanceText(text, button, successLabel, restingLabel) {
      try {
        await navigator.clipboard.writeText(text);
      } catch (error) {
        const fallback = document.createElement('textarea');
        fallback.value = text;
        fallback.setAttribute('readonly', '');
        fallback.style.position = 'fixed';
        fallback.style.opacity = '0';
        document.body.appendChild(fallback);
        fallback.select();
        const copied = document.execCommand('copy');
        fallback.remove();
        if (!copied) throw error;
      }
      button.innerText = successLabel;
      setTimeout(() => { button.innerText = restingLabel; }, 2400);
    }

    // Capture phase intentionally supersedes the legacy exhaustive handoff
    // listener retained below as historical source reference.
    if (copyHandoffBtn) {
      copyHandoffBtn.addEventListener('click', (event) => {
        event.stopImmediatePropagation();
        copyProvenanceText(
          buildCurrentHandoff(),
          copyHandoffBtn,
          'Copied Current Agent Handoff! ✓',
          '📋 Copy Current Agent Handoff'
        );
      }, { capture: true });
    }

    if (copyTelemetryBtn) {
      copyTelemetryBtn.addEventListener('click', (event) => {
        event.stopPropagation();
        copyProvenanceText(
          buildMachineTelemetry(),
          copyTelemetryBtn,
          'Copied Machine Telemetry! ✓',
          '⚙ Copy Machine Telemetry (.YAML)'
        );
      });
    }

    function getProvenanceFocusable() {
      if (!provModal) return [];
      return [...provModal.querySelectorAll('button, [href], input, textarea, select, [tabindex]:not([tabindex="-1"])')]
        .filter(el => !el.disabled && el.offsetParent !== null);
    }

    function setProvenanceOpen(open) {
      if (!provModal || !buildBadge) return;
      provModal.classList.toggle('open', open);
      provModal.setAttribute('aria-hidden', String(!open));
      buildBadge.setAttribute('aria-expanded', String(open));
      if (open) {
        provenanceReturnFocus = document.activeElement;
        requestAnimationFrame(() => provModal.focus());
      } else if (provenanceReturnFocus && typeof provenanceReturnFocus.focus === 'function') {
        provenanceReturnFocus.focus();
      }
    }

    function toggleProvModal() {
      setProvenanceOpen(!provModal?.classList.contains('open'));
    }

    if (buildBadge) {
      buildBadge.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleProvModal();
      });
    }

    if (provClose) {
      provClose.addEventListener('click', (e) => {
        e.stopPropagation();
        setProvenanceOpen(false);
      });
    }

    if (relockBtn) {
      relockBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        setProvenanceOpen(false);
        lockDossier();
      });
    }

    document.addEventListener('click', (e) => {
      if (provModal && provModal.classList.contains('open') && !e.target.closest('#build-provenance-modal') && !e.target.closest('#build-badge')) {
        setProvenanceOpen(false);
      }
    });

    // Touch & Click toggle on Version Item Rows (prevents stuck hover on iPad/mobile)
    const versionItems = document.querySelectorAll('.version-item-wrap');
    versionItems.forEach(item => {
      const row = item.querySelector('.version-item-row');
      if (row) {
        row.addEventListener('click', (e) => {
          e.stopPropagation();
          const wasActive = item.classList.contains('active');
          versionItems.forEach(vi => {
            vi.classList.remove('active');
            vi.querySelector('.version-item-row')?.setAttribute('aria-expanded', 'false');
          });
          if (!wasActive) {
            item.classList.add('active');
            row.setAttribute('aria-expanded', 'true');
          }
        });
        row.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            row.click();
          }
        });
      }
    });

    // Historical releases remain available in the on-page version archive.
    // Keyboard shortcut Shift + V to toggle provenance modal
    document.addEventListener('keydown', (e) => {
      if (provModal?.classList.contains('open') && e.key === 'Tab') {
        const focusable = getProvenanceFocusable();
        if (focusable.length === 0) {
          e.preventDefault();
          provModal.focus();
        } else {
          const first = focusable[0];
          const last = focusable[focusable.length - 1];
          if (document.activeElement === provModal) {
            e.preventDefault();
            (e.shiftKey ? last : first).focus();
          } else if (e.shiftKey && document.activeElement === first) {
            e.preventDefault();
            last.focus();
          } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault();
            first.focus();
          }
        }
      }
      if (e.shiftKey && (e.key === 'V' || e.key === 'v')) {
        if (!e.target.closest('input') && !e.target.closest('textarea')) {
          toggleProvModal();
        }
      }
    });

    // =========================================================================
    // 4. Red QR Code Generator SVG (Target: https://randybryanmoore.us)
    // =========================================================================
    function generateQRCodeSVG(text, size = 110, color = '2b0710') {
      const encoded = encodeURIComponent(text);
      return `<img src="https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encoded}&color=${color}" alt="QR Code to ${text}" width="${size}" height="${size}" style="display:block; border-radius:4px;" />`;
    }
    const qrTargets = document.querySelectorAll('.qr-code-target');
    qrTargets.forEach(el => {
      const sz = parseInt(el.getAttribute('data-size')) || 110;
      const targetUrl = el.getAttribute('data-url') || 'https://randybryanmoore.us';
      const color = el.getAttribute('data-color') || '2b0710';
      el.innerHTML = generateQRCodeSVG(targetUrl, sz, color);
    });

    // =========================================================================
    // 5. Case Studies Interactive Tab Switcher
    // =========================================================================
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');

    // Keep the performing-arts evidence near the case studies, before the
    // résumé-derived alignment, roadmap, and career-history sections.
    const caseStudiesSection = document.getElementById('case-studies');
    const musicSection = document.getElementById('music');
    if (caseStudiesSection && musicSection) {
      caseStudiesSection.insertAdjacentElement('afterend', musicSection);
    }

    tabBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        if (editActive) return;
        e.preventDefault();
        const tabId = btn.getAttribute('data-tab');
        tabBtns.forEach(b => b.classList.remove('active'));
        tabPanes.forEach(p => p.classList.remove('active'));

        btn.classList.add('active');
        const target = document.getElementById('tab-' + tabId);
        if (target) {
          target.classList.add('active');
        }
      });
    });

    // =========================================================================
    // 6. Dual-Stream Pinpoint Annotation & Private Notes Engine
    // =========================================================================
    let selectedElements = []; // Array of { el, tag, text }
    let selectedCategory = 'Copy';
    let aiNotesList = [];
    let privateNotesList = [];
    let activeDrawerTab = 'ai'; // 'ai', 'private', 'all'
    let badgesVisible = true;
    let searchQuery = '';

    // Load from localStorage
    try {
      const savedAi = localStorage.getItem('rbm_symphony_notes');
      if (savedAi) aiNotesList = JSON.parse(savedAi);
    } catch (e) { aiNotesList = []; }

    try {
      const savedPriv = localStorage.getItem('rbm_symphony_private_notes');
      if (savedPriv) privateNotesList = JSON.parse(savedPriv);
    } catch (e) { privateNotesList = []; }

    // Floating Dock Controls
    const pinAiToggle = document.getElementById('dock-pin-mode-btn');
    const pinPrivToggle = document.getElementById('dock-private-mode-btn');
    const editToggle = document.getElementById('dock-live-edit-btn');
    const drawerToggle = document.getElementById('dock-view-drawer-btn');
    const dockCount = document.getElementById('dock-notes-count');

    const inspectorBox = document.getElementById('inspector-box');
    const inspectorBadge = document.getElementById('inspector-badge');

    const popover = document.getElementById('annotation-popover');
    const popoverTitle = document.querySelector('.annotation-popover .popover-title');
    const popoverText = document.getElementById('popover-target-text');
    const popoverInput = document.getElementById('popover-comment-input');
    const popoverSave = document.getElementById('popover-save-btn');
    const popoverDismiss = document.getElementById('popover-dismiss-btn');
    const popoverClose = document.getElementById('popover-close-btn');
    const popoverModeTabs = document.querySelectorAll('.popover-mode-tab');
    const popoverTagsContainer = document.getElementById('popover-tags-container');

    const drawer = document.getElementById('feedback-drawer');
    const drawerClose = document.getElementById('drawer-close-btn');
    const drawerAiCount = document.getElementById('drawer-ai-count');
    const drawerPrivateCount = document.getElementById('drawer-private-count');
    const drawerAllCount = document.getElementById('drawer-all-count');
    const drawerTabs = document.querySelectorAll('.drawer-tab');
    const drawerSearch = document.getElementById('drawer-search-input');
    const drawerToggleBadgesBtn = document.getElementById('drawer-toggle-badges-btn');
    const drawerList = document.getElementById('drawer-items-list');
    const copyAiBtn = document.getElementById('drawer-copy-ai-btn');
    const clearAiBtn = document.getElementById('drawer-clear-ai-btn');
    const exportPrivateBtn = document.getElementById('drawer-export-private-btn');
    const clearPrivateBtn = document.getElementById('drawer-clear-private-btn');
    const footerAiActions = document.getElementById('drawer-footer-ai-actions');
    const footerPrivateActions = document.getElementById('drawer-footer-private-actions');
    const footerAllActions = document.getElementById('drawer-footer-all-actions');
    const copyAiAllBtn = document.getElementById('drawer-copy-ai-all-btn');
    const copyPrivateAllBtn = document.getElementById('drawer-copy-private-all-btn');

    const aiTags = ['Copy', 'Design', 'Data', 'Layout', 'Logic', 'Action Item'];
    const privateTags = ['Memo', 'Idea', 'Talking Point', 'Research', 'Follow-Up', 'Question'];

    function escapeHtml(str) {
      return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function renderTags() {
      if (!popoverTagsContainer) return;
      const tags = (currentMode === 'private') ? privateTags : aiTags;
      if (!tags.includes(selectedCategory)) {
        selectedCategory = tags[0];
      }
      popoverTagsContainer.innerHTML = tags.map(tag => `
        <span class="tag-chip ${selectedCategory === tag ? 'selected' : ''}" data-tag="${tag}">${tag}</span>
      `).join('');

      popoverTagsContainer.querySelectorAll('.tag-chip').forEach(chip => {
        chip.addEventListener('click', (e) => {
          e.stopPropagation();
          popoverTagsContainer.querySelectorAll('.tag-chip').forEach(c => c.classList.remove('selected'));
          chip.classList.add('selected');
          selectedCategory = chip.getAttribute('data-tag') || (currentMode === 'private' ? 'Memo' : 'Copy');
        });
      });
    }

    // Switch Popover Mode (AI Review vs Private Note)
    function setPopoverMode(mode) {
      currentMode = mode;
      popoverModeTabs.forEach(t => {
        if (t.getAttribute('data-mode') === mode) t.classList.add('active');
        else t.classList.remove('active');
      });

      if (mode === 'private') {
        if (popover) popover.classList.add('popover--private');
        if (popoverSave) popoverSave.innerText = 'Save Private Note ↵';
        if (pinPrivToggle) pinPrivToggle.classList.add('active');
        if (pinAiToggle) pinAiToggle.classList.remove('active');
      } else {
        if (popover) popover.classList.remove('popover--private');
        if (popoverSave) popoverSave.innerText = 'Pin for AI ↵';
        if (pinAiToggle) pinAiToggle.classList.add('active');
        if (pinPrivToggle) pinPrivToggle.classList.remove('active');
      }
      renderTags();
      renderSelectedElementsSnippet();
    }

    // Direct event delegation for popover tabs so it NEVER fails
    if (popover) {
      popover.addEventListener('click', (e) => {
        const tabBtn = e.target.closest('.popover-mode-tab');
        if (tabBtn) {
          e.preventDefault();
          e.stopPropagation();
          const mode = tabBtn.getAttribute('data-mode') || 'ai';
          setPopoverMode(mode);
        }
      });
    }

    function renderSelectedElementsSnippet() {
      if (!popoverText) return;
      if (selectedElements.length === 0) {
        popoverText.innerHTML = '<span style="color:var(--muted); font-style:italic;">No elements selected</span>';
        if (popoverTitle) popoverTitle.innerText = currentMode === 'private' ? '🔒 Private Note on Element' : 'Comment on Element';
        return;
      }
      
      const modePrefix = currentMode === 'private' ? '🔒 Private Note' : 'Comment';
      if (popoverTitle) {
        popoverTitle.innerText = selectedElements.length === 1 
          ? `${modePrefix} on Element` 
          : `${modePrefix} on ${selectedElements.length} Elements`;
      }

      const chipsHtml = selectedElements.map((item, idx) => `
        <div class="annotation-selection-chip" style="display:flex; justify-content:space-between; align-items:center; width:100%; background:var(--cream); padding:4px 8px; border-radius:4px; margin-bottom:4px; font-size:11px; border:1px solid var(--line);">
          <span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:240px; color:var(--ink);">
            <strong style="color:var(--maroon);">&lt;${item.tag}&gt;</strong> "${escapeHtml(item.text)}"
          </span>
          <button type="button" onclick="window.removeSelectedAnnotationElement(${idx})" title="Remove item" style="cursor:pointer; background:none; border:none; color:var(--maroon); font-weight:800; padding:0 4px; font-size:12px; line-height:1;">✕</button>
        </div>
      `).join('');

      popoverText.innerHTML = `
        <div style="max-height:80px; overflow-y:auto; margin-bottom:4px;">${chipsHtml}</div>
        <div style="font-size:10px; color:var(--muted); font-family:var(--mono);">💡 Click any element on page to add/remove from this batch</div>
      `;
    }

    window.removeSelectedAnnotationElement = function(index) {
      if (index >= 0 && index < selectedElements.length) {
        const removed = selectedElements.splice(index, 1)[0];
        if (removed && removed.el) {
          removed.el.classList.remove('annotation-target-selected');
        }
        if (selectedElements.length === 0) {
          closePopover();
        } else {
          renderSelectedElementsSnippet();
        }
      }
    };

    // Toggle Pin AI Mode from Dock
    if (pinAiToggle) {
      pinAiToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        if (pinActive && currentMode === 'ai') {
          pinActive = false;
          pinAiToggle.classList.remove('active');
          document.body.classList.remove('annotation-active');
          if (inspectorBox) inspectorBox.style.display = 'none';
          closePopover();
        } else {
          pinActive = true;
          currentMode = 'ai';
          if (editActive) {
            editActive = false;
            if (editToggle) editToggle.classList.remove('active');
            toggleEditableElements(false);
          }
          pinAiToggle.classList.add('active');
          if (pinPrivToggle) pinPrivToggle.classList.remove('active');
          document.body.classList.add('annotation-active');
        }
      });
    }

    // Toggle Private Note Mode from Dock
    if (pinPrivToggle) {
      pinPrivToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        if (pinActive && currentMode === 'private') {
          pinActive = false;
          pinPrivToggle.classList.remove('active');
          document.body.classList.remove('annotation-active');
          if (inspectorBox) inspectorBox.style.display = 'none';
          closePopover();
        } else {
          pinActive = true;
          currentMode = 'private';
          if (editActive) {
            editActive = false;
            if (editToggle) editToggle.classList.remove('active');
            toggleEditableElements(false);
          }
          pinPrivToggle.classList.add('active');
          if (pinAiToggle) pinAiToggle.classList.remove('active');
          document.body.classList.add('annotation-active');
        }
      });
    }

    // Toggle Live Edit Mode
    if (editToggle) {
      editToggle.addEventListener('click', () => {
        editActive = !editActive;
        if (editActive) {
          if (pinActive) {
            pinActive = false;
            if (pinAiToggle) pinAiToggle.classList.remove('active');
            if (pinPrivToggle) pinPrivToggle.classList.remove('active');
            document.body.classList.remove('annotation-active');
            if (inspectorBox) inspectorBox.style.display = 'none';
            closePopover();
          }
          editToggle.classList.add('active');
          toggleEditableElements(true);
        } else {
          editToggle.classList.remove('active');
          toggleEditableElements(false);
        }
      });
    }

    function toggleEditableElements(enable) {
      const candidates = document.querySelectorAll('h1, h2, h3, h4, p, li, strong, blockquote, .stat-num, .stat-label, .wordmark-title, button, .button, .tab-btn, span');
      candidates.forEach(el => {
        if (!el.closest('#annotation-dock') && !el.closest('#annotation-popover') && !el.closest('#feedback-drawer') && !el.closest('#passcode-gate') && !el.closest('#build-provenance-modal')) {
          el.contentEditable = enable ? 'true' : 'false';
          el.style.outline = enable ? '1.5px dashed rgba(76, 14, 28, 0.4)' : '';
          el.style.outlineOffset = enable ? '2px' : '';
        }
      });
    }

    // Toggle Drawer
    if (drawerToggle) {
      drawerToggle.addEventListener('click', () => {
        if (drawer) {
          drawer.style.display = (drawer.style.display === 'flex') ? 'none' : 'flex';
          if (drawer.style.display === 'flex') updateDrawer();
        }
      });
    }
    if (drawerClose) {
      drawerClose.addEventListener('click', () => {
        if (drawer) drawer.style.display = 'none';
      });
    }

    function openDrawerToTab(tabName) {
      if (drawer) drawer.style.display = 'flex';
      setDrawerTab(tabName);
    }

    // Drawer Tabs
    drawerTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const tabName = tab.getAttribute('data-tab');
        setDrawerTab(tabName);
      });
    });

    function setDrawerTab(tabName) {
      activeDrawerTab = tabName;
      drawerTabs.forEach(t => {
        if (t.getAttribute('data-tab') === tabName) t.classList.add('active');
        else t.classList.remove('active');
      });

      if (footerAiActions && footerPrivateActions && footerAllActions) {
        if (tabName === 'private') {
          footerAiActions.style.display = 'none';
          footerPrivateActions.style.display = 'flex';
          footerAllActions.style.display = 'none';
        } else if (tabName === 'all') {
          footerAiActions.style.display = 'none';
          footerPrivateActions.style.display = 'none';
          footerAllActions.style.display = 'flex';
        } else {
          footerAiActions.style.display = 'flex';
          footerPrivateActions.style.display = 'none';
          footerAllActions.style.display = 'none';
        }
      }
      updateDrawer();
    }

    // Drawer Search Filter
    if (drawerSearch) {
      drawerSearch.addEventListener('input', (e) => {
        searchQuery = e.target.value.toLowerCase().trim();
        updateDrawer();
      });
    }

    // Toggle Badge Visibility
    if (drawerToggleBadgesBtn) {
      drawerToggleBadgesBtn.addEventListener('click', () => {
        badgesVisible = !badgesVisible;
        document.querySelectorAll('.annotation-element-badge').forEach(b => {
          b.style.display = badgesVisible ? 'flex' : 'none';
        });
        drawerToggleBadgesBtn.innerText = badgesVisible ? '👁️ Badges On' : '🙈 Badges Hidden';
      });
    }

    // Inspector Hover Box Tracking
    document.addEventListener('mousemove', (e) => {
      if (!pinActive || editActive) {
        if (inspectorBox) inspectorBox.style.display = 'none';
        return;
      }

      const target = document.elementFromPoint(e.clientX, e.clientY);
      if (!target || target.closest('#annotation-dock') || target.closest('#annotation-popover') || target.closest('#feedback-drawer') || target.closest('#inspector-box') || target.closest('#passcode-gate') || target.closest('#build-provenance-modal') || target.closest('#build-badge') || target.closest('.annotation-element-badge')) {
        if (inspectorBox) inspectorBox.style.display = 'none';
        return;
      }

      const rect = target.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;

      if (inspectorBox) {
        inspectorBox.style.top = rect.top + 'px';
        inspectorBox.style.left = rect.left + 'px';
        inspectorBox.style.width = rect.width + 'px';
        inspectorBox.style.height = rect.height + 'px';
        inspectorBox.style.display = 'block';
        inspectorBox.style.borderColor = 'var(--maroon)';
        inspectorBox.style.background = 'rgba(43, 7, 16, 0.08)';

        const tag = target.tagName.toLowerCase();
        const snippet = target.innerText ? target.innerText.trim().substring(0, 24) : '';
        if (inspectorBadge) {
          const modeLabel = (currentMode === 'private') ? '🔒 Private' : '🚀 AI';
          inspectorBadge.innerText = `[${modeLabel}] <${tag}> ${snippet ? `"${snippet}..."` : ''}`;
          inspectorBadge.style.background = 'var(--maroon)';
          inspectorBadge.style.color = 'var(--cream)';
        }
      }
    });

    // Click to Target and Open Popover (with Multi-Element Selection)
    document.addEventListener('click', (e) => {
      if (editActive && e.target.closest('a')) {
        e.preventDefault();
        return;
      }
      if (!pinActive || editActive) return;
      if (e.target.closest('#annotation-dock') || e.target.closest('#annotation-popover') || e.target.closest('#feedback-drawer') || e.target.closest('.annotation-element-badge') || e.target.closest('#passcode-gate') || e.target.closest('#build-provenance-modal') || e.target.closest('#build-badge')) return;

      e.preventDefault();
      e.stopPropagation();

      const clickedEl = e.target;
      const existingIdx = selectedElements.findIndex(item => item.el === clickedEl);

      if (existingIdx !== -1) {
        selectedElements.splice(existingIdx, 1);
        clickedEl.classList.remove('annotation-target-selected');
        if (selectedElements.length === 0) {
          closePopover();
          return;
        }
      } else {
        const rawText = clickedEl.innerText ? clickedEl.innerText.trim() : (clickedEl.getAttribute('alt') || clickedEl.getAttribute('title') || '');
        const tag = clickedEl.tagName.toLowerCase();
        const snippet = rawText.length > 75 ? rawText.substring(0, 72) + '...' : (rawText || `<${tag}> element`);

        clickedEl.classList.add('annotation-target-selected');
        selectedElements.push({
          el: clickedEl,
          tag: tag,
          text: snippet
        });
      }

      setPopoverMode(currentMode);

      const rect = clickedEl.getBoundingClientRect();
      if (popover) {
        const popoverWidth = 350;
        const popoverHeight = 280;
        let topPos = rect.bottom + 8;
        let leftPos = Math.max(16, Math.min(window.innerWidth - popoverWidth - 16, rect.left));

        if (topPos + popoverHeight > window.innerHeight) {
          topPos = Math.max(16, rect.top - popoverHeight - 8);
        }

        popover.style.top = topPos + 'px';
        popover.style.left = leftPos + 'px';
        popover.style.display = 'block';

        if (selectedElements.length === 1) {
          renderTags();
          setTimeout(() => { if (popoverInput) popoverInput.focus(); }, 50);
        }
      }
    });

    // Save Annotation Note (Dual-Stream Batch Support)
    function saveNote() {
      const comment = popoverInput ? popoverInput.value.trim() : '';
      if (!comment) {
        if (popoverInput) {
          popoverInput.style.borderColor = 'red';
          popoverInput.focus();
          setTimeout(() => { popoverInput.style.borderColor = ''; }, 1200);
        }
        return;
      }
      if (selectedElements.length === 0) return;

      const isPrivate = (currentMode === 'private');
      const targetList = isPrivate ? privateNotesList : aiNotesList;
      const storageKey = isPrivate ? 'rbm_symphony_private_notes' : 'rbm_symphony_notes';

      selectedElements.forEach((item, idx) => {
        const num = targetList.length + 1;
        const noteId = (isPrivate ? 'priv-' : 'note-') + Date.now() + '-' + idx;

        if (item.el) {
          item.el.classList.remove('annotation-target-selected');
          item.el.classList.add(isPrivate ? 'annotation-target-active--private' : 'annotation-target-active');
          item.el.setAttribute('data-annotation-id', noteId);

          const badge = document.createElement('span');
          badge.className = isPrivate ? 'annotation-element-badge annotation-element-badge--private' : 'annotation-element-badge';
          badge.innerText = isPrivate ? `🔒${num}` : num;
          badge.title = `[${isPrivate ? '🔒 Private' : '🚀 AI'}: ${selectedCategory}] ${comment}`;
          badge.setAttribute('data-badge-id', noteId);
          badge.addEventListener('click', (ev) => {
            ev.stopPropagation();
            openDrawerToTab(isPrivate ? 'private' : 'ai');
          });
          item.el.appendChild(badge);
        }

        const newNote = {
          id: num,
          noteId: noteId,
          tag: item.tag,
          type: isPrivate ? 'private' : 'ai',
          category: selectedCategory,
          targetText: item.text,
          comment: comment,
          createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };

        targetList.push(newNote);
      });

      try {
        localStorage.setItem(storageKey, JSON.stringify(targetList));
      } catch (e) {}

      closePopover();
      updateDrawer();
    }

    function closePopover() {
      if (popover) popover.style.display = 'none';
      selectedElements.forEach(item => {
        if (item.el) item.el.classList.remove('annotation-target-selected');
      });
      selectedElements = [];
      if (popoverInput) popoverInput.value = '';
    }

    if (popoverSave) popoverSave.addEventListener('click', saveNote);
    if (popoverDismiss) popoverDismiss.addEventListener('click', closePopover);
    if (popoverClose) popoverClose.addEventListener('click', closePopover);

    // Keyboard Shortcuts
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (popover && popover.style.display === 'block') closePopover();
        if (provModal && provModal.classList.contains('open')) setProvenanceOpen(false);
        if (pinActive) {
          pinActive = false;
          if (pinAiToggle) pinAiToggle.classList.remove('active');
          if (pinPrivToggle) pinPrivToggle.classList.remove('active');
          document.body.classList.remove('annotation-active');
          if (inspectorBox) inspectorBox.style.display = 'none';
        }
      }
      if ((e.key === 'Enter' && e.ctrlKey) || (e.key === 'Enter' && !e.shiftKey && document.activeElement === popoverInput)) {
        if (popover && popover.style.display === 'block') {
          e.preventDefault();
          saveNote();
        }
      }
    });

    // Update Drawer UI
    function updateDrawer() {
      const totalCount = aiNotesList.length + privateNotesList.length;
      if (dockCount) dockCount.innerText = totalCount;
      if (drawerAiCount) drawerAiCount.innerText = aiNotesList.length;
      if (drawerPrivateCount) drawerPrivateCount.innerText = privateNotesList.length;
      if (drawerAllCount) drawerAllCount.innerText = totalCount;

      if (!drawerList) return;

      let displayNotes = [];
      if (activeDrawerTab === 'ai') displayNotes = [...aiNotesList];
      else if (activeDrawerTab === 'private') displayNotes = [...privateNotesList];
      else displayNotes = [...aiNotesList, ...privateNotesList];

      if (searchQuery) {
        displayNotes = displayNotes.filter(n => 
          n.comment.toLowerCase().includes(searchQuery) ||
          n.category.toLowerCase().includes(searchQuery) ||
          n.targetText.toLowerCase().includes(searchQuery) ||
          n.tag.toLowerCase().includes(searchQuery)
        );
      }

      if (displayNotes.length === 0) {
        const emptyMsg = activeDrawerTab === 'private'
          ? 'No private notes yet. Click "🔒 Private Note" on the bottom dock or toggle to "🔒 Private Note" in the popover to pin your personal thoughts.'
          : (activeDrawerTab === 'ai' 
              ? 'No AI review notes queued. Click "🚀 Pin AI" on the dock and pin changes to send to Antigravity/Claude.'
              : 'No notes match your filter.');
        drawerList.innerHTML = `<p style="color:var(--muted);font-size:12px;font-style:italic;padding:12px;text-align:center;">${emptyMsg}</p>`;
        return;
      }

      drawerList.innerHTML = displayNotes.map(n => {
        const isPriv = (n.type === 'private');
        const badgeLabel = isPriv ? `🔒#${n.id}` : `#${n.id}`;
        return `
          <div class="drawer-item ${isPriv ? 'drawer-item--private' : ''}" id="drawer-item-${n.noteId}">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
              <span style="font-family:var(--mono); font-size:11px; font-weight:800; color:var(--maroon);">
                ${badgeLabel} · ${n.category} <span style="font-weight:400; opacity:0.8; font-size:10px;">(${n.createdAt})</span>
              </span>
              <div style="display:flex; gap:4px;">
                <button onclick="window.jumpToAnnotatedElement('${n.noteId}')" style="background:var(--navy); color:white; border:none; border-radius:3px; padding:2px 6px; font-size:9.5px; cursor:pointer; font-weight:700;">Jump</button>
                <button onclick="window.deleteAnnotationNote('${n.noteId}', '${n.type}')" style="background:var(--cream); color:var(--maroon); border:1px solid var(--line); border-radius:3px; padding:2px 6px; font-size:9.5px; cursor:pointer; font-weight:700;" title="Delete note">✕</button>
              </div>
            </div>
            <div style="font-size:10.5px; color:var(--muted); margin-bottom:4px;">Target: <em>&lt;${n.tag}&gt; "${escapeHtml(n.targetText)}"</em></div>
            <p style="font-size:12px; line-height:1.45; margin:0; color:var(--ink);">${escapeHtml(n.comment)}</p>
          </div>
        `;
      }).join('');
    }

    // Global helper for jumping to element with spotlight ripple
    window.jumpToAnnotatedElement = function(noteId) {
      const el = document.querySelector(`[data-annotation-id="${noteId}"]`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.classList.remove('annotation-spotlight-pulse');
        void el.offsetWidth;
        el.classList.add('annotation-spotlight-pulse');
      }
    };

    // Global helper for deleting note
    window.deleteAnnotationNote = function(noteId, type) {
      if (type === 'private') {
        privateNotesList = privateNotesList.filter(n => n.noteId !== noteId);
        try { localStorage.setItem('rbm_symphony_private_notes', JSON.stringify(privateNotesList)); } catch (e) {}
      } else {
        aiNotesList = aiNotesList.filter(n => n.noteId !== noteId);
        try { localStorage.setItem('rbm_symphony_notes', JSON.stringify(aiNotesList)); } catch (e) {}
      }
      const badge = document.querySelector(`[data-badge-id="${noteId}"]`);
      if (badge) badge.remove();
      updateDrawer();
    };

    // Copy All AI Notes Formatted for AI
    if (copyAiBtn) {
      copyAiBtn.addEventListener('click', () => {
        if (aiNotesList.length === 0) {
          alert('No AI review notes queued! Click "🚀 Pin AI" to add critique.');
          return;
        }
        let prompt = "### Review Notes for Richmond Symphony Portfolio Refinements\n\n";
        aiNotesList.forEach(n => {
          prompt += `**[#${n.id}] [${n.category}] on <${n.tag}> "${n.targetText}"**\n`;
          prompt += `- **Feedback/Revision**: ${n.comment}\n\n`;
        });
        navigator.clipboard.writeText(prompt).then(() => {
          copyAiBtn.innerText = 'Copied to Clipboard! ✓';
          
          // Clear ONLY the AI review notes list (private notes are NEVER touched!)
          aiNotesList = [];
          try {
            localStorage.setItem('rbm_symphony_notes', JSON.stringify(aiNotesList));
          } catch (e) {}
          
          // Remove ONLY the AI badges (private badges are preserved!)
          document.querySelectorAll('.annotation-element-badge:not(.annotation-element-badge--private)').forEach(b => b.remove());
          
          updateDrawer();
          setTimeout(() => { copyAiBtn.innerText = 'Copy Prompt for AI'; }, 2400);
        });
      });
    }

    // Clear AI Notes Queue
    if (clearAiBtn) {
      clearAiBtn.addEventListener('click', () => {
        if (aiNotesList.length === 0) return;
        if (confirm('Clear the AI Review Queue?')) {
          aiNotesList = [];
          try { localStorage.setItem('rbm_symphony_notes', JSON.stringify(aiNotesList)); } catch (e) {}
          document.querySelectorAll('.annotation-element-badge:not(.annotation-element-badge--private)').forEach(b => b.remove());
          updateDrawer();
        }
      });
    }

    // Copy All Private Notes Formatted as Markdown Journal (Explicitly Preserves 100% of Notes with ZERO Deletions)
    function copyAllPrivateNotes() {
      if (privateNotesList.length === 0) {
        alert('No private notes recorded yet! Click "🔒 Private Note" on the dock to add your personal notes.');
        return;
      }
      let doc = "# 🔒 Richmond Symphony Portfolio — Personal Notes & Working Memos\n";
      doc += `*Exported on ${new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} — All notes preserved locally*\n\n---\n\n`;
      privateNotesList.forEach(n => {
        doc += `### [🔒#${n.id}] [${n.category}] on <${n.tag}> "${n.targetText}"\n`;
        doc += `- **Note**: ${n.comment}\n`;
        doc += `- *Created*: ${n.createdAt}\n\n`;
      });

      navigator.clipboard.writeText(doc).then(() => {
        if (exportPrivateBtn) exportPrivateBtn.innerText = 'Copied All Private Notes (Preserved)! ✓';
        if (copyPrivateAllBtn) copyPrivateAllBtn.innerText = 'Copied Private (Preserved)! ✓';
        setTimeout(() => {
          if (exportPrivateBtn) exportPrivateBtn.innerText = '🔒 Copy All Private Notes (Never Deleted)';
          if (copyPrivateAllBtn) copyPrivateAllBtn.innerText = '🔒 Copy Private (Preserved)';
        }, 2500);
      });
    }

    if (exportPrivateBtn) exportPrivateBtn.addEventListener('click', copyAllPrivateNotes);
    if (copyPrivateAllBtn) copyPrivateAllBtn.addEventListener('click', copyAllPrivateNotes);

    if (copyAiAllBtn && copyAiBtn) {
      copyAiAllBtn.addEventListener('click', () => {
        copyAiBtn.click();
      });
    }

    // Clear Private Notes with Confirmation
    if (clearPrivateBtn) {
      clearPrivateBtn.addEventListener('click', () => {
        if (privateNotesList.length === 0) return;
        if (confirm('Are you sure you want to permanently clear all your Private Notes?')) {
          privateNotesList = [];
          try { localStorage.setItem('rbm_symphony_private_notes', JSON.stringify(privateNotesList)); } catch (e) {}
          document.querySelectorAll('.annotation-element-badge--private').forEach(b => b.remove());
          updateDrawer();
        }
      });
    }

    renderTags();
    updateDrawer();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSuite);
  } else {
    initSuite();
  }
})();
